﻿CREATE TABLE IF NOT EXISTS cc128_readings
(
	temperature TINYINT,
	watts SMALLINT,
	datetime TIMESTAMP
);